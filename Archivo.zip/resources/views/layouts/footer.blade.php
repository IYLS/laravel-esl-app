@auth
@if(Auth::user())

<div class="mt-auto text-white-50 bg-dark p-3">
    <div class="">
        <footer class="d-flex justify-content-center">
            <p>&#169; 2022 www.ideasforlistening.com </p>
        </footer>
    </div>    
</div>

@endif
@endauth